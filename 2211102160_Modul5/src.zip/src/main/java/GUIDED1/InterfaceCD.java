/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package GUIDED1;
//Fatimah Az Zahra-2211102160-IF10K
interface InterfaceCD {
    // Metode untuk mencetak detail CD
    void cetakCD();

    // Metode untuk mendapatkan harga CD
    long getHargaCD();
}