/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package GUIDED1;

//Nama: Fatimah Az Zahra
//NIM : 2211102160
//Kelas: IF-10-K
public class Main {
    public static void main(String[] args) {
        //orientasi buku baru
        Buku a = new Buku(); //pemanggilan kelas Buku
        a.setNilai("Bumi", "Tere Liye", 13);
        a.cetakKeLayar();
    }
}
