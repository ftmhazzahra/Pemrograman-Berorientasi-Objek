/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package GUIDED2;
//Fatimah Az Zahra_2211102160_If10K
// Kelas anak yang mewarisi kelas Mammal, merepresentasikan Duck
public class Duck extends Mammal {
    // Metode untuk bersuara
    public void speak(){
        System.out.println("Quack! Quack!");
    }
}
