/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package GUIDED2;
//Fatimah Az Zahra_2211102160_If10K
public class Mammal {
    protected String name; // Atribut nama yang dilindungi
    // Metode untuk tidur
    public void sleep(){
        System.out.println("zzzz zzzz zzzz");
    }
}

